package hurraa;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

public class HurraaSovellusTest {

    @Test
    @Points("14-08")
    public void noTests() {

    }
}
